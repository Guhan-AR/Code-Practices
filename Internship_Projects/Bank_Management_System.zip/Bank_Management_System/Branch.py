class Branch:

    def __init__(self,bank_name : str,branch_id : int,name_of_branch : str):

        self.Name = bank_name
        self.id = branch_id
        self.Branch_name = name_of_branch
