class Account:

    def __init__(self,account_id : int , amount_in_account : int ,account_type : str):

        self.Id = account_id
        self.Balance = amount_in_account
        self.Type = account_type
