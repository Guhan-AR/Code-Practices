class Customer:

    def __init__(self,customer_name :str ,customer_id : int,customer_phone_number : int , customer_address : str , customer_pan_card_number : int):

        self.Name = customer_name
        self.Id = customer_id
        self.Phone_number = customer_phone_number
        self.Address = customer_address
        self.Pan_card_number = customer_pan_card_number
