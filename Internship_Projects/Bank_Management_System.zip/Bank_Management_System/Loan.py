class Loan:

    def __init__(self,loan_id : int,loan_amount : int , loan_type : str):

        self.Id = loan_id
        self.Amount = loan_amount
        self.Type = loan_type
