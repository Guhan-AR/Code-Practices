from django.apps import AppConfig


class DasappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dasapp'
